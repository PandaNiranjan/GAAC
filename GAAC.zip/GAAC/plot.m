% Load and preprocess data (Step 1)
data = readtable('heart_disease_data.csv');
data = fillmissing(data, 'constant', 0);
data{:, 1:end-1} = normalize(data{:, 1:end-1});
[trainData, testData] = splitData(data, 0.7);

% Feature extraction with Diffusion Maps (Step 2)
epsilon = 1;
numFeatures = 10;
[mappedTrainDataDiffusion, ~] = diffusionMaps(trainData{:, 1:end-1}, epsilon, numFeatures);
[mappedTestDataDiffusion, ~] = diffusionMaps(testData{:, 1:end-1}, epsilon, numFeatures);

% Feature extraction with PCA
[coeff, score, ~, ~, explained] = pca(trainData{:, 1:end-1});

% Plotting
figure;
scatter(mappedTrainDataDiffusion(:,1), mappedTrainDataDiffusion(:,2), 'b', 'filled');
hold on;
scatter(score(:,1), score(:,2), 'r', 'filled');
xlabel('Feature 1');
ylabel('Feature 2');
legend('Diffusion Maps', 'PCA');
title('Scatter Plot of Diffusion Maps vs PCA');
hold off;

